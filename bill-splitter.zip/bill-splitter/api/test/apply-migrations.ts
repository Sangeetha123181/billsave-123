import { applyD1Migrations, env } from "cloudflare:test";

declare module "cloudflare:test" {
  interface ProvidedEnv {
    DB: D1Database;
    TEST_MIGRATIONS: D1Migration[];
  }
}

// Applies every file in api/migrations/ before the tests run.
await applyD1Migrations(env.DB, env.TEST_MIGRATIONS);
