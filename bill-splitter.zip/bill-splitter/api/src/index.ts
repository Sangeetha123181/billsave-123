import { type Context, Hono } from "hono";

type AppEnv = { Bindings: { DB: D1Database } };
type Ctx = Context<AppEnv>;

type HomeRow = { id: string; name: string };
type MemberRow = { id: string; home_id: string; name: string };
type BillRow = { id: string; home_id: string; title: string; total_cents: number };
type ShareRow = {
  id: string;
  bill_id: string;
  member_id: string;
  amount_cents: number;
  paid_at: string | null;
  payment_key: string | null;
};

const MAX_TEXT = 100;
const MAX_KEY = 200;

const app = new Hono<AppEnv>();

// ---------- helpers ----------

const fail = (c: Ctx, status: 400 | 404 | 409 | 422, error: string) => c.json({ error }, status);

async function readObject(req: Request): Promise<Record<string, unknown> | null> {
  try {
    const value: unknown = await req.json();
    if (typeof value === "object" && value !== null && !Array.isArray(value)) {
      return value as Record<string, unknown>;
    }
    return null;
  } catch {
    return null;
  }
}

function cleanText(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const text = value.trim();
  return text.length > 0 && text.length <= MAX_TEXT ? text : null;
}

/** Share `index` of `count`: equal split, leftover cents go to the first members. */
export function shareAmount(totalCents: number, count: number, index: number): number {
  const base = Math.floor(totalCents / count);
  const extra = totalCents % count;
  return base + (index < extra ? 1 : 0);
}

const toShare = (row: ShareRow) => ({
  id: row.id,
  memberId: row.member_id,
  amountCents: row.amount_cents,
  paidAt: row.paid_at,
});

const getHome = (c: Ctx, id: string) =>
  c.env.DB.prepare("SELECT id, name FROM homes WHERE id = ?1").bind(id).first<HomeRow>();

const getShare = (c: Ctx, billId: string, shareId: string) =>
  c.env.DB.prepare(
    "SELECT id, bill_id, member_id, amount_cents, paid_at, payment_key FROM shares WHERE id = ?1 AND bill_id = ?2",
  )
    .bind(shareId, billId)
    .first<ShareRow>();

// ---------- health ----------

app.get("/api/health", (c) => c.json({ status: "ok" }));

// ---------- part 1: homes and members ----------

app.get("/api/homes", async (c) => {
  const { results } = await c.env.DB.prepare("SELECT id, name FROM homes ORDER BY rowid").all<HomeRow>();
  return c.json({ homes: results });
});

app.post("/api/homes", async (c) => {
  const name = cleanText((await readObject(c.req.raw))?.name);
  if (name === null) return fail(c, 400, `name must be 1-${MAX_TEXT} characters`);
  const id = crypto.randomUUID();
  await c.env.DB.prepare("INSERT INTO homes (id, name) VALUES (?1, ?2)").bind(id, name).run();
  return c.json({ id, name }, 201);
});

app.get("/api/homes/:homeId/members", async (c) => {
  const homeId = c.req.param("homeId");
  if (!(await getHome(c, homeId))) return fail(c, 404, "home not found");
  const { results } = await c.env.DB.prepare(
    "SELECT id, home_id, name FROM members WHERE home_id = ?1 ORDER BY rowid",
  )
    .bind(homeId)
    .all<MemberRow>();
  return c.json({ members: results.map((m) => ({ id: m.id, homeId: m.home_id, name: m.name })) });
});

app.post("/api/homes/:homeId/members", async (c) => {
  const homeId = c.req.param("homeId");
  if (!(await getHome(c, homeId))) return fail(c, 404, "home not found");
  const name = cleanText((await readObject(c.req.raw))?.name);
  if (name === null) return fail(c, 400, `name must be 1-${MAX_TEXT} characters`);
  const id = crypto.randomUUID();
  await c.env.DB.prepare("INSERT INTO members (id, home_id, name) VALUES (?1, ?2, ?3)")
    .bind(id, homeId, name)
    .run();
  return c.json({ id, homeId, name }, 201);
});

// ---------- part 2: bills ----------

app.get("/api/homes/:homeId/bills", async (c) => {
  const homeId = c.req.param("homeId");
  if (!(await getHome(c, homeId))) return fail(c, 404, "home not found");
  const bills = await c.env.DB.prepare(
    "SELECT id, home_id, title, total_cents FROM bills WHERE home_id = ?1 ORDER BY rowid DESC",
  )
    .bind(homeId)
    .all<BillRow>();
  const shares = await c.env.DB.prepare(
    `SELECT s.id, s.bill_id, s.member_id, s.amount_cents, s.paid_at, s.payment_key
     FROM shares s JOIN bills b ON b.id = s.bill_id
     WHERE b.home_id = ?1 ORDER BY s.rowid`,
  )
    .bind(homeId)
    .all<ShareRow>();
  const byBill = new Map<string, ReturnType<typeof toShare>[]>();
  for (const s of shares.results) {
    const list = byBill.get(s.bill_id) ?? [];
    list.push(toShare(s));
    byBill.set(s.bill_id, list);
  }
  return c.json({
    bills: bills.results.map((b) => ({
      id: b.id,
      homeId: b.home_id,
      title: b.title,
      totalCents: b.total_cents,
      shares: byBill.get(b.id) ?? [],
    })),
  });
});

app.post("/api/homes/:homeId/bills", async (c) => {
  const homeId = c.req.param("homeId");
  if (!(await getHome(c, homeId))) return fail(c, 404, "home not found");

  const body = await readObject(c.req.raw);
  const title = cleanText(body?.title);
  const total = body?.totalCents;
  if (title === null) return fail(c, 422, `title must be 1-${MAX_TEXT} characters`);
  if (typeof total !== "number" || !Number.isSafeInteger(total) || total <= 0) {
    return fail(c, 422, "totalCents must be a positive whole number");
  }

  const members = await c.env.DB.prepare("SELECT id FROM members WHERE home_id = ?1 ORDER BY rowid")
    .bind(homeId)
    .all<{ id: string }>();
  if (members.results.length === 0) return fail(c, 422, "home has no members");

  const billId = crypto.randomUUID();
  const shares = members.results.map((m, i) => ({
    id: crypto.randomUUID(),
    memberId: m.id,
    amountCents: shareAmount(total, members.results.length, i),
    paidAt: null,
  }));

  // One atomic batch: a bill never exists without all of its shares.
  await c.env.DB.batch([
    c.env.DB.prepare("INSERT INTO bills (id, home_id, title, total_cents) VALUES (?1, ?2, ?3, ?4)").bind(
      billId,
      homeId,
      title,
      total,
    ),
    ...shares.map((s) =>
      c.env.DB.prepare(
        "INSERT INTO shares (id, bill_id, member_id, amount_cents) VALUES (?1, ?2, ?3, ?4)",
      ).bind(s.id, billId, s.memberId, s.amountCents),
    ),
  ]);

  return c.json({ id: billId, homeId, title, totalCents: total, shares }, 201);
});

// ---------- part 2: paying ----------

app.post("/api/bills/:billId/shares/:shareId/pay", async (c) => {
  const key = c.req.header("Idempotency-Key")?.trim();
  if (!key || key.length > MAX_KEY) return fail(c, 400, "Idempotency-Key header is required");

  const { billId, shareId } = c.req.param();
  if (!(await getShare(c, billId, shareId))) return fail(c, 404, "bill or share not found");

  // The WHERE ... paid_at IS NULL makes this a single atomic compare-and-set:
  // with two simultaneous requests, SQLite lets exactly one update a row.
  const paidAt = new Date().toISOString();
  const result = await c.env.DB.prepare(
    "UPDATE shares SET paid_at = ?1, payment_key = ?2 WHERE id = ?3 AND bill_id = ?4 AND paid_at IS NULL",
  )
    .bind(paidAt, key, shareId, billId)
    .run();

  const share = await getShare(c, billId, shareId);
  if (!share) return fail(c, 404, "bill or share not found");
  if (result.meta.changes === 1 || share.payment_key === key) return c.json(toShare(share), 200);
  return fail(c, 409, "share already paid with a different Idempotency-Key");
});

// ---------- part 2: balances ----------

app.get("/api/homes/:homeId/balances", async (c) => {
  const homeId = c.req.param("homeId");
  if (!(await getHome(c, homeId))) return fail(c, 404, "home not found");
  const { results } = await c.env.DB.prepare(
    `SELECT m.id AS memberId, m.name AS name,
            COALESCE(SUM(CASE WHEN s.paid_at IS NULL THEN s.amount_cents END), 0) AS outstandingCents
     FROM members m LEFT JOIN shares s ON s.member_id = m.id
     WHERE m.home_id = ?1
     GROUP BY m.id ORDER BY m.rowid`,
  )
    .bind(homeId)
    .all<{ memberId: string; name: string; outstandingCents: number }>();
  return c.json({ balances: results });
});

// ---------- errors: always JSON ----------

app.notFound((c) => c.json({ error: "not found" }, 404));
app.onError((err, c) => {
  console.error(err);
  return c.json({ error: "internal server error" }, 500);
});

export default app;
