-- Ids are random text. Insertion order (rowid) is the "order members were added".

CREATE TABLE homes (
  id   TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  -- stops: empty or whitespace-only home names
  CONSTRAINT homes_name_not_blank CHECK (length(trim(name)) > 0)
);

CREATE TABLE members (
  id      TEXT PRIMARY KEY,
  home_id TEXT NOT NULL,
  name    TEXT NOT NULL,
  -- stops: members that belong to a home that does not exist
  CONSTRAINT members_home_fk FOREIGN KEY (home_id) REFERENCES homes (id) ON DELETE CASCADE,
  CONSTRAINT members_name_not_blank CHECK (length(trim(name)) > 0)
);
CREATE INDEX members_home_idx ON members (home_id);

CREATE TABLE bills (
  id          TEXT PRIMARY KEY,
  home_id     TEXT NOT NULL,
  title       TEXT NOT NULL,
  total_cents INTEGER NOT NULL,
  CONSTRAINT bills_home_fk FOREIGN KEY (home_id) REFERENCES homes (id) ON DELETE CASCADE,
  CONSTRAINT bills_title_not_blank CHECK (length(trim(title)) > 0),
  -- stops: zero, negative, or non-integer (REAL/TEXT) money amounts
  CONSTRAINT bills_total_positive_integer CHECK (typeof(total_cents) = 'integer' AND total_cents > 0)
);
CREATE INDEX bills_home_idx ON bills (home_id);

CREATE TABLE shares (
  id           TEXT PRIMARY KEY,
  bill_id      TEXT NOT NULL,
  member_id    TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  paid_at      TEXT,
  payment_key  TEXT,
  CONSTRAINT shares_bill_fk FOREIGN KEY (bill_id) REFERENCES bills (id) ON DELETE CASCADE,
  CONSTRAINT shares_member_fk FOREIGN KEY (member_id) REFERENCES members (id) ON DELETE CASCADE,
  -- stops: charging the same member twice for one bill
  CONSTRAINT shares_one_per_member UNIQUE (bill_id, member_id),
  CONSTRAINT shares_amount_valid CHECK (typeof(amount_cents) = 'integer' AND amount_cents >= 0),
  -- stops: a share that is "paid" without a key, or a key without a payment
  CONSTRAINT shares_paid_has_key CHECK ((paid_at IS NULL) = (payment_key IS NULL))
);
CREATE INDEX shares_bill_idx ON shares (bill_id);
CREATE INDEX shares_member_idx ON shares (member_id);
