# Shared Bill Splitter

Hono on Cloudflare Workers + D1 (API), React + Vite + TanStack Router (web).

```
pnpm install
pnpm dev        # api :8787, web :5173
pnpm check:fix && pnpm check && pnpm typecheck && pnpm test
```

## Decisions

1. **Atomic compare-and-set for payment.** `UPDATE shares SET paid_at, payment_key WHERE id = ? AND paid_at IS NULL`.
   SQLite lets only one of two simultaneous requests change the row, so there is no
   read-then-write race. If it changed nothing, a same-key request gets the stored result (200),
   a different key gets 409.
2. **Bill and shares in one `db.batch`.** D1 runs a batch as a transaction, so a bill can never
   exist with missing shares. Split maths is integer-only: `floor(total / n)` plus one extra cent
   for the first `total % n` members, in insertion (rowid) order.
3. **Rules live in the schema, not only in code.** Named constraints (`bills_total_positive_integer`,
   `shares_one_per_member`, `shares_paid_has_key`, the foreign keys) keep data valid even if a
   handler has a bug. The web client generates one Idempotency-Key per share and reuses it on
   retry, with a 10 s timeout, so a slow or failing API never double-pays or crashes the page.

## AI use
Fill in which tools you used and where.
