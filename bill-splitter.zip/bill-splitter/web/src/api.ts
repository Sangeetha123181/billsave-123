const TIMEOUT_MS = 10_000;

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export const messageOf = (e: unknown): string =>
  e instanceof Error ? e.message : "Something went wrong.";

type Options = { method?: string; body?: unknown; headers?: Record<string, string> };

function errorText(data: unknown): string | null {
  if (typeof data === "object" && data !== null && "error" in data) {
    const { error } = data as { error: unknown };
    if (typeof error === "string") return error;
  }
  return null;
}

/** Never throws anything but ApiError, and never waits longer than TIMEOUT_MS. */
export async function request<T>(path: string, options: Options = {}): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(path, {
      method: options.method ?? "GET",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", ...options.headers },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    });
    const data: unknown = await res.json().catch(() => null);
    if (!res.ok) throw new ApiError(errorText(data) ?? `Request failed (${res.status}).`, res.status);
    return data as T;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    if (controller.signal.aborted) throw new ApiError("The server took too long to answer.", 0);
    throw new ApiError("Could not reach the server.", 0);
  } finally {
    clearTimeout(timer);
  }
}
