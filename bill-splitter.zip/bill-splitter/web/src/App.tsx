import { type FormEvent, type ReactNode, useEffect, useRef, useState } from "react";
import { messageOf, request } from "./api";

type Home = { id: string; name: string };
type Member = { id: string; name: string };
type Share = { id: string; memberId: string; amountCents: number; paidAt: string | null };
type Bill = { id: string; title: string; totalCents: number; shares: Share[] };
type Balance = { memberId: string; name: string; outstandingCents: number };

type Load<T> =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; data: T };

const money = (cents: number) =>
  (cents / 100).toLocaleString("en-US", { style: "currency", currency: "USD" });

/** "12.5" -> 1250. Pure string maths, so no floating point ever touches money. */
function parseCents(input: string): number | null {
  const m = /^(\d{1,9})(?:\.(\d{1,2}))?$/.exec(input.trim());
  if (!m) return null;
  const cents = Number(m[1]) * 100 + Number((m[2] ?? "").padEnd(2, "0"));
  return cents > 0 ? cents : null;
}

function useLoad<T>(path: string): { state: Load<T>; reload: () => void } {
  const [state, setState] = useState<Load<T>>({ status: "loading" });
  const [tick, setTick] = useState(0);
  // biome-ignore lint/correctness/useExhaustiveDependencies: tick re-runs the request on demand
  useEffect(() => {
    let stale = false;
    request<T>(path)
      .then((data) => !stale && setState({ status: "ready", data }))
      .catch((e: unknown) => !stale && setState({ status: "error", message: messageOf(e) }));
    return () => {
      stale = true;
    };
  }, [path, tick]);
  return { state, reload: () => setTick((t) => t + 1) };
}

function Async<T>(props: { state: Load<T>; reload: () => void; children: (data: T) => ReactNode }) {
  const { state, reload, children } = props;
  if (state.status === "loading") return <p className="note">Loading…</p>;
  if (state.status === "error") {
    return (
      <div className="note error" role="alert">
        <p>{state.message}</p>
        <button type="button" onClick={reload}>
          Try again
        </button>
      </div>
    );
  }
  return <>{children(state.data)}</>;
}

function AddForm(props: {
  label: string;
  action: string;
  fields: { name: string; label: string; placeholder: string }[];
  onSubmit: (values: Record<string, string>) => Promise<void>;
}) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await props.onSubmit(values);
      setValues({});
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} aria-label={props.label}>
      {props.fields.map((f) => (
        <label key={f.name}>
          {f.label}
          <input
            value={values[f.name] ?? ""}
            placeholder={f.placeholder}
            onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}
            required
          />
        </label>
      ))}
      <button type="submit" disabled={busy}>
        {busy ? "Saving…" : props.action}
      </button>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
    </form>
  );
}

function BillCard(props: { bill: Bill; names: Map<string, string>; onPaid: () => void }) {
  const { bill, names, onPaid } = props;
  const [paying, setPaying] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  // One key per share, kept until the payment succeeds: a retry is then safe.
  const keys = useRef(new Map<string, string>());

  async function pay(share: Share) {
    const key = keys.current.get(share.id) ?? crypto.randomUUID();
    keys.current.set(share.id, key);
    setPaying(share.id);
    setErrors(({ [share.id]: _, ...rest }) => rest);
    try {
      await request(`/api/bills/${bill.id}/shares/${share.id}/pay`, {
        method: "POST",
        headers: { "Idempotency-Key": key },
      });
      keys.current.delete(share.id);
      onPaid();
    } catch (e) {
      setErrors((prev) => ({ ...prev, [share.id]: messageOf(e) }));
    } finally {
      setPaying(null);
    }
  }

  return (
    <article className="bill">
      <header>
        <h3>{bill.title}</h3>
        <strong>{money(bill.totalCents)}</strong>
      </header>
      <ul>
        {bill.shares.map((s) => (
          <li key={s.id}>
            <div className="row">
              <span>{names.get(s.memberId) ?? "Former member"}</span>
              <span className="dots" aria-hidden="true" />
              <span className="amount">{money(s.amountCents)}</span>
              {s.paidAt ? (
                <span className="paid">Paid</span>
              ) : (
                <button type="button" disabled={paying === s.id} onClick={() => pay(s)}>
                  {paying === s.id ? "Paying…" : "Pay"}
                </button>
              )}
            </div>
            {errors[s.id] && (
              <p className="error" role="alert">
                Payment failed, share is still unpaid: {errors[s.id]}
              </p>
            )}
          </li>
        ))}
      </ul>
    </article>
  );
}

function HomeView({ home }: { home: Home }) {
  const base = `/api/homes/${home.id}`;
  const members = useLoad<{ members: Member[] }>(`${base}/members`);
  const bills = useLoad<{ bills: Bill[] }>(`${base}/bills`);
  const balances = useLoad<{ balances: Balance[] }>(`${base}/balances`);

  const names = new Map(
    members.state.status === "ready" ? members.state.data.members.map((m) => [m.id, m.name]) : [],
  );

  return (
    <div className="layout">
      <aside>
        <h2>Members</h2>
        <Async {...members}>
          {({ members: list }) =>
            list.length === 0 ? (
              <p className="note">No members yet. Add one to start splitting bills.</p>
            ) : (
              <ul className="plain">
                {list.map((m) => (
                  <li key={m.id}>{m.name}</li>
                ))}
              </ul>
            )
          }
        </Async>
        <AddForm
          label="Add member"
          action="Add member"
          fields={[{ name: "name", label: "Name", placeholder: "Asha" }]}
          onSubmit={async (v) => {
            await request(`${base}/members`, { method: "POST", body: { name: v.name } });
            members.reload();
            balances.reload();
          }}
        />

        <h2>Still owed</h2>
        <Async {...balances}>
          {({ balances: list }) => (
            <ul className="plain">
              {list.map((b) => (
                <li key={b.memberId} className="row">
                  <span>{b.name}</span>
                  <span className="dots" aria-hidden="true" />
                  <span className="amount">{money(b.outstandingCents)}</span>
                </li>
              ))}
            </ul>
          )}
        </Async>
      </aside>

      <section>
        <h2>Bills</h2>
        <AddForm
          label="Add bill"
          action="Split bill"
          fields={[
            { name: "title", label: "What for", placeholder: "Electricity" },
            { name: "amount", label: "Total (USD)", placeholder: "100.00" },
          ]}
          onSubmit={async (v) => {
            const totalCents = parseCents(v.amount ?? "");
            if (totalCents === null) throw new Error("Enter an amount like 12.50.");
            await request(`${base}/bills`, {
              method: "POST",
              body: { title: v.title, totalCents },
            });
            bills.reload();
            balances.reload();
          }}
        />
        <Async {...bills}>
          {({ bills: list }) =>
            list.length === 0 ? (
              <p className="note">No bills yet. Add one above and it is split between members.</p>
            ) : (
              list.map((b) => (
                <BillCard
                  key={b.id}
                  bill={b}
                  names={names}
                  onPaid={() => {
                    bills.reload();
                    balances.reload();
                  }}
                />
              ))
            )
          }
        </Async>
      </section>
    </div>
  );
}

export function App() {
  const homes = useLoad<{ homes: Home[] }>("/api/homes");
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <main>
      <h1>Shared bill splitter</h1>
      <Async {...homes}>
        {({ homes: list }) => {
          const home = list.find((h) => h.id === selected) ?? list[0];
          return (
            <>
              {list.length === 0 && <p className="note">No homes yet. Create the first one.</p>}
              {home && (
                <label className="picker">
                  Home
                  <select value={home.id} onChange={(e) => setSelected(e.target.value)}>
                    {list.map((h) => (
                      <option key={h.id} value={h.id}>
                        {h.name}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              <AddForm
                label="Create home"
                action="Create home"
                fields={[{ name: "name", label: "New home", placeholder: "Flat 4B" }]}
                onSubmit={async (v) => {
                  const created = await request<Home>("/api/homes", {
                    method: "POST",
                    body: { name: v.name },
                  });
                  setSelected(created.id);
                  homes.reload();
                }}
              />
              {home && <HomeView key={home.id} home={home} />}
            </>
          );
        }}
      </Async>
    </main>
  );
}
